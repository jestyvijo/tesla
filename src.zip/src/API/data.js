export const data = {
    projects: [
      {
        image:"compositor.jpg",
        title: "Model 3",
        category: "Car",
        price:49040,
        reduceprice:50490,
        description: "",
      },
      {
        image:"compositor1.jpg",
        title: "Model S",
        category: "Car",
        price:77020,
        reduceprice:82990,
        description: "",
      },
      {
        image:"compositor2.jpg",
        title: "Model X",
        category: "Car",
        price:80570,
        reduceprice:86490,
        description: "",
      },
      {
        image:"compositor3.jpg",
        title: "Model Y",
        category: "Car",
        price:53510,
        reduceprice:55490,
        description: "Model Y Performance Dual Motor All-Wheel Drive",
      }
    ]
  };