export const data = {
    projects: [
      {
        title: "Project title 1",
        category: "frontend development",
        description: "",
        desktop: [
          {
            resolution: "640 x 480",
            price: 2500
          }
        ],
        mobile: []
      },
      {
        title: "Project title 2",
        category: "frontend development",
        description: "",
        desktop: [
          {
            resolution: "1280 x 720",
            price: 5500
          }
        ],
        mobile: []
      }
    ]
  };