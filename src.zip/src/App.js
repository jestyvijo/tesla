import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbars from './Navbars';

function App() {
  return (
   <>
   <Navbars/>
   </>
  );
}

export default App;
